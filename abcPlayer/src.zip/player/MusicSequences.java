package player;

public interface MusicSequences {

}
